rm -r /data/user/0/com.tencent.tmgp.pubgmhd/files
echo "down删除成功"